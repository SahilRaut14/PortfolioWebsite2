import speech_recognition as sr
import datetime
import subprocess
import pywhatkit 
import pyttsx3
import webbrowser

engine=pyttsx3.init()
voices=engine.getProperty('voices')
engine.setPropertty('voice'[1].id)

def cmd():
    with sr.Microphone() as source:

         

